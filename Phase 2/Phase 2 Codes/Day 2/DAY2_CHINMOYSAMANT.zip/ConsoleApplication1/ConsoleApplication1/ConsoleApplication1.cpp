// ConsoleApplication1.cpp : Defines the entry point for the console application.


#include "stdafx.h"
#include "opencv2\core\core.hpp"
#include "opencv2\highgui\highgui.hpp"
#include <iostream>
#include <stdio.h>
using namespace cv;
using namespace std;


int main(int argc, _TCHAR* argv[])
{
	/*
	namedWindow("my window", WINDOW_AUTOSIZE);
	int x = 128,y=128,z=128;
	Mat image;
	image = imread("c://ronaldo.jpg", 1);
	Mat bin(image.size(), CV_8UC3);
	int rows, cols, i, j;
	rows = image.rows;
	cols = image.cols;
	createTrackbar("blue", "my window", &x, 255);
	createTrackbar("green", "my window", &y, 255);
	createTrackbar("red", "my window", &z, 255);
	while (1)
	{
		for (i = 0; i < rows; i++)
		{
			for (j = 0; j < cols; j++)
			{
				if (image.at<Vec3b>(i, j)[0] <= z)
				{
					bin.at<Vec3b>(i, j)[0] = 0;
				}
				else
					bin.at<Vec3b>(i, j)[0] = 255;
				if (image.at<Vec3b>(i, j)[1] <= y)
				{
					bin.at<Vec3b>(i, j)[1] = 0;
				}
				else
					bin.at<Vec3b>(i, j)[1] = 255;
				if (image.at<Vec3b>(i, j)[2] <= x)
				{
					bin.at<Vec3b>(i, j)[2] = 0;
				}
				else
					bin.at<Vec3b>(i, j)[2] = 255;
			}
		}
		imshow("my window",bin);
		char a = waitKey(33);
		if (a == 27)
			break;
	}
	*/
	namedWindow("my window", WINDOW_AUTOSIZE);
	int x = 128;
	Mat image;
	image = imread("c://ronaldo.jpg", 1);
	Mat bin(image.size(), CV_8UC3);
	int rows, cols, i, j;
	rows = image.rows;
	cols = image.cols;
	createTrackbar("brightness", "my window", &x, 100);
	createTrackbar("contrast", "my window", &x, 255);
	while (1)
	{
		
	}

	return 0;
}

