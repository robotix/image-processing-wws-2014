// Computer Vision.cpp : Defines the entry point for the console application.
#include "stdafx.h"
#include "opencv2\core\core.hpp"
#include "opencv2\highgui\highgui.hpp"
#include <iostream>
#include <stdio.h>
using namespace std;
using namespace cv;


/*
Mat flag()
{
	Mat img(999, 999, CV_8UC3);
	int i, j;
	for (i = 0; i < 999; i++)
	{
		for (j = 0; j < 999;j++)
		{
			if (j < 333)
			{
				img.at<Vec3b>(j, i)[0] = 0;
				img.at<Vec3b>(j, i)[1] = 165;
				img.at<Vec3b>(j, i)[2] = 255;
				
			}
			if (j > 332 && j < 666)
			{
					img.at<Vec3b>(j, i)[0] = 255;
					img.at<Vec3b>(j, i)[1] = 255;
					img.at<Vec3b>(j, i)[2] = 255;
		    }
			if (j > 665 && j < 999)
			{
				img.at<Vec3b>(j, i)[0] = 0;
				img.at<Vec3b>(j, i)[1] = 255;
				img.at<Vec3b>(j, i)[2] = 0;

			}
		}		
	}
	return img;
}
/*
Mat imagegrayscale(Mat image)
{
	Mat greyimage(image.size(),CV_8UC1);
	int rows, cols, i, j; 
	rows = image.rows;
	cols = image.cols;
	for (i = 0; i < rows; i++)
	{
		for (j = 0; j < cols; j++)
		{
			greyimage.at<uchar>(i, j) = (image.at<Vec3b>(i, j)[0] + image.at<Vec3b>(i, j)[1] + image.at<Vec3b>(i, j)[2]) / 3;

		}
	}
	return greyimage;
	
}
*/




int main(int argc, _TCHAR* argv[])
{

	/*namedWindow("my window", WINDOW_AUTOSIZE);
	Mat image(999,999,CV_8UC3);
	image = flag();
	imshow("my window", image);
	waitKey(0);



	/*
	Mat image;
	char address[1000];
	// cout << "enter the address of the image";
	// gets(address);
	image = imread("C:\\Users\\CHINMOY SAM\\Pictures\\untitled.png", CV_LOAD_IMAGE_COLOR);
	Mat greyimage = imagegrayscale(image);
	namedWindow("my window", WINDOW_AUTOSIZE);
	imshow("my window", greyimage);
	waitKey(0);
	return 0;
	*/

	Mat image;
	int value, i, j, rows, cols;
	/*char addr[1000];
	cout << "enter the address of the image";
	cin >> addr;
	*/
	image = imread("C:\\Users\\CHINMOY SAM\\Pictures\\untitled1.png", CV_LOAD_IMAGE_COLOR);
	Mat invertimage(image.size(), CV_8UC3);
	cout << "enter the way to flip \n 1 > horizontal\n 2 > vertical\n 3 > diagonal\n";
	cin >> value;
	rows = image.rows;
	cols = image.cols;
	if (value == 1)
	{
		for (i = 0; i < rows; i++)
		{
			for (j = 0; j < cols; j++)
			{

				invertimage.at<Vec3b>(rows - i - 1, j)[0] = image.at<Vec3b>(i, j)[0];
				invertimage.at<Vec3b>(rows - i - 1, j)[1] = image.at<Vec3b>(i, j)[1];
				invertimage.at<Vec3b>(rows - i - 1, j)[2] = image.at<Vec3b>(i, j)[2];
			}
		}
	}
	
	if (value == 2)
	{
		for (i = 0; i < cols; i++)
		{
			for (j = 0; j < rows; j++)
			{
				invertimage.at<Vec3b>(j, cols - i - 1)[0] = image.at<Vec3b>(j, i)[0];
				invertimage.at<Vec3b>(j, cols - i - 1)[1] = image.at<Vec3b>(j, i)[1];
				invertimage.at<Vec3b>(j, cols - i - 1)[2] = image.at<Vec3b>(j, i)[2];
			}
		}
	}
	if (value == 3)
	{
		for (i = 0; i < rows; i++)
		{
			for (j = 0; j < cols; j++)
			{
				invertimage.at<Vec3b>(rows - i - 1, cols - j - 1)[0] = image.at<Vec3b>(i, j)[0];
				invertimage.at<Vec3b>(rows - i - 1, cols - j - 1)[1] = image.at<Vec3b>(i, j)[1];
				invertimage.at<Vec3b>(rows - i - 1, cols - j - 1)[2] = image.at<Vec3b>(i, j)[2];
			}
		}
	}
	namedWindow("my window", WINDOW_AUTOSIZE);
	imshow("my window", invertimage);
	waitKey(0);
	return 0;
}

	
	/*
	Mat image = imread("C:\\Users\\CHINMOY SAM\\Pictures\\untitled.png", CV_LOAD_IMAGE_GRAYSCALE);
	int freq[256], i, j, rows, cols, numb, thres, sum=0,max;
	for (i = 0; i < 256; i++)
		freq[i] = 0;
	rows = image.rows;
	cols = image.cols;
	numb = cols*rows;
	for (i = 0; i < rows; i++)
	{
		for (j = 0; j < cols; j++)
		{
			freq[image.at<uchar>(i, j)]++;
		}
	}
	max = freq[0];
	for (i = 0; i < 256; i++)
	{
		if (freq[i]>max)
			max = freq[i];
	}
	Mat graph(max, 256, CV_8UC1, Scalar(0)); 
	for (i = 0; i<256 ; i++)
	{
		for (j = max-1; j >max-freq[i]-1; j--)
		{
			graph.at<uchar>(j, i) = 255;
		}
	}
	namedWindow("my window", WINDOW_AUTOSIZE);
	namedWindow("my window 1", WINDOW_AUTOSIZE);
	imshow("my window", graph);
	imshow("my window 1", image);
	waitKey(0);
	for (i = 0; i < 256; i++)
	{
		sum += freq[i];
		if (sum>numb / 2)
			break;
	}
	thres = i;
	for (i = 0; i < rows; i++)
	{
		for (j = 0; j < cols; j++)
		{
			if (image.at<uchar>(i, j) < thres)
				image.at<uchar>(i, j) = 0;
			else
				image.at<uchar>(i, j) = 255;
		}
	}
		return 0;
}
*/



	




	
		


	