#include"stdafx.h"

#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

using namespace std;
using namespace cv;
/*int main()
{
	Mat image,image2;

	image = imread("c:\\fire.jpg", CV_LOAD_IMAGE_GRAYSCALE);
	namedWindow("MyWindow", WINDOW_AUTOSIZE);
	imshow("MyWindow", image);
	int value = image.at<uchar>(50, 500);
	cout <<value;
	cout << "\n"
	waitKey(0);

	image2 = imread("c:\\RS.jpg", CV_LOAD_IMAGE_GRAYSCALE);
	namedWindow("Secondwindow", WINDOW_AUTOSIZE);
	imshow("Secondwindow", image2);
	cout << "Finish 1st program";
	waitKey(0);
  
	}*/