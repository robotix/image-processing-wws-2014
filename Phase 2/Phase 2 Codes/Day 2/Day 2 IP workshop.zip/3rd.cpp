#include"stdafx.h"
#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#define FACTOR 100

using namespace std;
using namespace cv;
void greyscale(Mat colorimage, Mat greyimage)
{
	for (int i = 0; i < colorimage.rows; i++)
	{
		for (int j = 0; j < colorimage.cols; j++)
		{
			greyimage.at<uchar>(i, j) = ((colorimage.at<Vec3b>(i, j)[0])*.56) + ((colorimage.at<Vec3b>(i, j)[1])*.33) + ((colorimage.at<Vec3b>(i, j)[2])*.11);
		}
	}
}
void binaryimage(Mat greyimage, Mat binaryimage,int k)
{
	for (int i = 0; i < greyimage.rows; i++)
	{
		for (int j = 0; j < greyimage.cols; j++)
		{
			if ((greyimage.at<uchar>(i, j))>k)
			{
				binaryimage.at<uchar>(i, j) = 255;
			}
			else
			{
				binaryimage.at<uchar>(i, j) = 0;
			}
		}
	}
}
void invert(Mat colorimage, Mat invertimage)
{
	for (int i = (colorimage.rows - 1); i >= 0; --i)
	{
		for (int j = 0; j < colorimage.cols; j++)
		{

			invertimage.at<Vec3b>(i, j)[0] = colorimage.at<Vec3b>(((colorimage.rows - 1) - i), j)[0];
			invertimage.at<Vec3b>(i, j)[1] = colorimage.at<Vec3b>(((colorimage.rows - 1) - i), j)[1];
			invertimage.at<Vec3b>(i, j)[2] = colorimage.at<Vec3b>(((colorimage.rows - 1) - i), j)[2];
		}
		}

}
void histogram(Mat greyimage,Mat image,int k)
{
	int a[256] = {0};
	for (int s = 0; s < 256; ++s)
	{
		
		for (int i = 0; i < greyimage.rows; i++)
		{

			for (int j = 0; j < greyimage.cols; j++)
			{
				if ((greyimage.at<uchar>(i, j)) == s)
					a[s] += 1;

			}
		}
	}

		for (int i = 0; i < 256; ++i)
			{
				for (int j = ((k-1)/100); j >=a[i]/100; j--)
					{
						image.at<uchar>(j,i) = 0;
					}
			}
	}

int main()

{
	
	Mat image=imread("c:\\tree.jpg", CV_LOAD_IMAGE_COLOR);
Mat image2(image.rows, image.cols, CV_8UC1);
//Mat image3(image.rows, image.cols, CV_8UC1);
//Mat image4(image.rows, image.cols, CV_8UC3);
Mat histimage((image2.rows)*(image2.cols)/FACTOR,256, CV_8UC1,Scalar(255));
namedWindow("Histogram", WINDOW_NORMAL);
//cout << "Enter the threshold";
//cin >> t;
//cout << (image.rows)*(image.cols);
greyscale(image, image2);
//binaryimage(image2, image3,t);
//invert(image, image4);
histogram(image2,histimage,((image2.rows)*(image2.cols)));
//imshow("MyWindow", image);
//waitKey(0);
//imshow("GREYWindow", image2);
//waitKey(0);
//imshow("BianryWindow", image3);
//waitKey(0);
//imshow("InvertWindow", image4);
//waitKey(0);
imshow("Histogram", histimage);
waitKey(0);
}