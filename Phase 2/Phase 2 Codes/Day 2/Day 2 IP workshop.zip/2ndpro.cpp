#include "stdafx.h"
/*
#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

using namespace std;
using namespace cv;*/
/*int main()
{
	Mat image(600,600,CV_8UC3,Scalar(0.0,0));

	image = imread("c:\\fire.jpg", CV_LOAD_IMAGE_COLOR);
	namedWindow("MyWindow", WINDOW_AUTOSIZE);
	for (int i = 0; i < image.rows; i++)
	{
		for (int j = 0; j < image.cols; j++)
		{
			image.at<Vec3b>(i, j)[0] = 0;
			image.at<Vec3b>(i, j)[1] = 0;
			
				}
	}
	cout << (int)image.at<Vec3b>((image.rows) / 2, (image.cols) / 2)[2];
	imshow("MyWindow", image);
	waitKey(0);
}*/