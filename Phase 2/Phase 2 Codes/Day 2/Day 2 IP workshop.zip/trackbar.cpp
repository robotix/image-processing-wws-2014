#include"stdafx.h"
#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

using namespace std;
using namespace cv;
/*Mat binaryimage(Mat greyimage, int k)
{
	Mat bi(greyimage.rows,greyimage.cols,CV_8UC1);
	for (int i = 0; i < greyimage.rows; i++)
	{
		for (int j = 0; j < greyimage.cols; j++)
		{
			if ((greyimage.at<uchar>(i, j))>k)
			{
				bi.at<uchar>(i, j) = 255;
			}
			else
			{
				bi.at<uchar>(i, j) = 0;
			}
		}
	}
	return bi;
}
void greyscale(Mat colorimage, Mat greyimage)
{
	for (int i = 0; i < colorimage.rows; i++)
	{
		for (int j = 0; j < colorimage.cols; j++)
		{
			greyimage.at<uchar>(i, j) = ((colorimage.at<Vec3b>(i, j)[0])*.56) + ((colorimage.at<Vec3b>(i, j)[1])*.33) + ((colorimage.at<Vec3b>(i, j)[2])*.11);
		}
	}
}
int main()
{
	int x=125;
	Mat image = imread("c:\\tree.jpg", CV_LOAD_IMAGE_COLOR);
	Mat image2(image.rows, image.cols, CV_8UC1);
	greyscale(image, image2);
	namedWindow("WINDOW1", WINDOW_NORMAL);
	createTrackbar("threshold", "WINDOW1", &x, 255);
	while (1)
	{
		Mat ti = binaryimage(image2, x);
		imshow("WINDOW1", ti);
		char a = waitKey(33);
		if (a == 27)
			break;
	}
}*/