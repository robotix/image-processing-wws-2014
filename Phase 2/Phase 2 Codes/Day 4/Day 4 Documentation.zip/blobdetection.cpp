#include"stdafx.h"
#include <iostream>
#include<math.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include<queue>
using namespace std;
using namespace cv;
/*int main()
{

	queue<Point> q;
	Mat image = imread("c://paint.jpeg");
	Mat image1(image.rows,image.cols,CV_8UC1,Scalar(0));

	int a[5000][5000];
	for (int i = 0; i < image.rows; i++)
	{
		for (int j = 0; j < image.cols; j++)
		{
			a[j][i] = -1;
		}
	}
	int l = 0;
	Point p, z;
	for (int i = 0; i < image.rows; i++)
	{
		for (int j = 0; j < image.cols; j++)
		{

			if ((a[j][i] == -1) && (image.at<uchar>(i, j) == 255))
			{
				l += 1;

				z.x = j;
				z.y = i;
				q.push(z);
				a[j][i] = 0;


				do{
					for (int k = (z.y - 1); k <= (z.y + 1); k++)
					{
						for (int s = (z.x - 1); s <= (z.x + 1); s++)
						{
							if ((a[s][k] == -1) && (image.at<uchar>(k, s) == 255))

							{
								a[s][k] = 0;

								p.x = s;
								p.y = k;
								q.push(p);
							}
						}
					}
					a[z.x][z.y]=l;
					q.pop();
					if (!q.empty())
						z = q.front();
				} while (a[z.x][z.y] == 0);
			}

		}
}
	for (int i = 0; i < image.rows; i++)
	{
		for (int j = 0; j < image.cols; j++)
		{
			if (a[j][i] == 1)
				image1.at<uchar>(i, j) = 255;
			if (a[j][i] == 2)
				image1.at<uchar>(i, j) = (255 / 2);
			if (a[j][i] == 3)
				image1.at<uchar>(i, j) = (255 / 3);
			if (a[j][i] == 4)
				image1.at<uchar>(i, j) = (255 / 4);

		}

		}
	imshow("Queue", image1);
	waitKey(0);
}*/

		
		
