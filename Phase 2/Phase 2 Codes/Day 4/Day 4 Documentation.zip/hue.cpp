#include"stdafx.h"
#include <iostream>
#include<math.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

using namespace std;
using namespace cv;
int main()
{
	int H = 72;
	int h;
	Mat image = imread("c://tree.jpg", CV_LOAD_IMAGE_COLOR);
	Mat image2;
	Mat image3(image.rows, image.cols,CV_8UC1, Scalar(0));
	cvtColor(image, image2, CV_BGR2HLS);
	namedWindow("New", WINDOW_NORMAL);
	createTrackbar("Hthreshold", "New", &h, 21);
	
	for (int i = 0; i < image.rows; i++)
	{
		for (int j = 0; j < image.cols; j++)
		{
			if (((image2.at<Vec3b>(i, j)[0]) >= (H - h)) && ((image2.at<Vec3b>(i, j)[0]) <= (H + h)))
				image3.at<uchar>(i, j) = 255;
		}
	}
	imshow("New", image3);
	waitKey(0);
}