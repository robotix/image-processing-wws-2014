#include"stdafx.h"
#include <iostream>
#include<math.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

using namespace std;
using namespace cv;
/*void greyscale(Mat colorimage, Mat greyimage)
{
	for (int i = 0; i < colorimage.rows; i++)
	{
		for (int j = 0; j < colorimage.cols; j++)
		{
			greyimage.at<uchar>(i, j) = ((colorimage.at<Vec3b>(i, j)[0])*.56) + ((colorimage.at<Vec3b>(i, j)[1])*.33) + ((colorimage.at<Vec3b>(i, j)[2])*.11);
		}
	}
}*/
/*int main()
{
	int x = 50;
	int y = 125;
 	VideoCapture V("c://Baby.mp4");
	namedWindow("Vedio", WINDOW_NORMAL);
	createTrackbar("minthreshold", "Vedio", &x, 255);
	createTrackbar("maxthreshold", "Vedio", &y, 255);
	while (1)
	{   
		Mat frame;
		V >> frame;
		Mat greyframe(frame.rows, frame.cols, CV_8UC1);
		Mat image6(frame.rows, frame.cols, CV_8UC1);
		Canny(frame, image6, x, y);
		imshow("Vedio", image6);
		char a = waitKey(33);
		if (a == 27)
			break;
	}
}*/