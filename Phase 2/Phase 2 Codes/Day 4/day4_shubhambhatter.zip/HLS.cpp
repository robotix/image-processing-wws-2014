#include "stdafx.h"
#include<iostream>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <stdio.h>
#include<opencv2/imgproc/imgproc.hpp>


using namespace cv;
using namespace std;

int main()
{
	Mat image = imread("C:\\Users\\Subham Bhatter\\Downloads\\8-mile_english-249922\\download (5).jpg", CV_LOAD_IMAGE_COLOR);
	Mat copy;
	int t1 = 6;
	int t2 = 6;
	int t3 = 6;
	int k = 50;
	int l = 20;
	cvtColor(image, copy, CV_RGB2HLS);
	namedWindow("Window1", WINDOW_NORMAL);
	int a;
	int h = 20;
	int s = 20;
	createTrackbar("Thresholdhue", "Window1", &t1, 255);
	createTrackbar("Thresholdlight", "Window1", &t2, 255);
	createTrackbar("Thresholdsat", "Window1", &t3, 255);
	createTrackbar("Hue", "Window1", &h, 255);
	createTrackbar("light", "Window1", &l, 255);
	createTrackbar("Saturation", "Window1", &s, 255);
	
	int i, j;
	while (1)
	{
		Mat img(image.rows, image.cols, CV_8UC1, Scalar(255));
		for (i = 0; i < copy.rows; i++)
		{
			for (j = 0; j < copy.cols; j++)
			{
				if (copy.at<Vec3b>(i, j)[0]>(h - t1) && copy.at<Vec3b>(i, j)[0] < h + t1)
				{
					img.at<uchar>(i, j) = 0;
				}


			}
		}
		for (i = 0; i < copy.rows; i++)
		{
			for (j = 0; j < copy.cols; j++)
			{
				if (copy.at<Vec3b>(i, j)[2]>(s- t3) && copy.at<Vec3b>(i, j)[2] < s + t3)
				{
					img.at<uchar>(i, j) = 0;
				}


			}
		}
		for (i = 0; i < copy.rows; i++)
		{
			for (j = 0; j < copy.cols; j++)
			{
				if (copy.at<Vec3b>(i, j)[1]>(l - t2) && copy.at<Vec3b>(i, j)[1] < l + t2)
				{
					img.at<uchar>(i, j) = 0;
				}


			}
		}
		imshow("Window1", img);
		a = waitKey(33);
		if (a == 27)
		{
			break;
		}
	}
}


