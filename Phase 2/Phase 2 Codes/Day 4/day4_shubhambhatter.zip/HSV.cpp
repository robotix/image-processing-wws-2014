#include "stdafx.h"
#include<iostream>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <stdio.h>
#include<opencv2/imgproc/imgproc.hpp>


using namespace cv;
using namespace std;

int main()
{
	Mat image = imread("C:\\Users\\Subham Bhatter\\Downloads\\8-mile_english-249922\\download (5).jpg", CV_LOAD_IMAGE_COLOR);
	Mat copy;
	int t = 6;
	int k = 50;
	int l = 20;
	cvtColor(image, copy, CV_BGR2HSV);
	namedWindow("Window1", WINDOW_NORMAL);
	int a;
	createTrackbar("Threshold", "Window1", &t, 255);
	Mat img(image.rows, image.cols, CV_8UC1, Scalar(255));
	int i, j;
	while (1)
	{
		for (i = 0; i < copy.rows; i++)
		{
			for (j = 0; j < copy.cols; j++)
			{
				if (copy.at<Vec3b>(i, j)[0]>(8 - t) && copy.at<Vec3b>(i, j)[0] < 8 + t)
				{
					img.at<uchar>(i, j) = 0;
				}


			}
		}
		imshow("Window1", img);
		a = waitKey(33);
		if (a == 27)
		{
			break;
		}
	}
	}


