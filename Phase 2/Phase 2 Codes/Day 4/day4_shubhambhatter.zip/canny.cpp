#include "stdafx.h"
#include<iostream>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <stdio.h>
#include<opencv2/imgproc/imgproc.hpp>


using namespace cv;
using namespace std;
Mat makebinary(Mat, int);

int main()
{
	Mat image = imread("C:\\Users\\Subham Bhatter\\Downloads\\mast-sherlock-s3-mini-episode-hires.jpg", CV_LOAD_IMAGE_GRAYSCALE);
	Mat copy(image.rows, image.cols, CV_8UC1);
	int t = 100;
	int k = 50;
	int l=20;
	namedWindow("Window1", WINDOW_NORMAL);
	createTrackbar("Threshold", "Window1", &l, 255);
	createTrackbar("Upper", "Window1", &t, 255);
	createTrackbar("Lower", "Window1", &k, 255);
	VideoCapture v(0);
	int a;
		while (1)
		{
			Mat Frame;
			 v>> Frame;
			Canny(Frame, copy, k, t, 3);
			imshow("Window1", copy);
			a = waitKey(1);
			if (a == 27)
				break;
		}

		}

