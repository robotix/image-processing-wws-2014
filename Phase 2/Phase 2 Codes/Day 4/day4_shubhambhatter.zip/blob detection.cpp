#include "stdafx.h"
#include<iostream>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <stdio.h>
#include<opencv2/imgproc/imgproc.hpp>
#include<queue>
#include<stdlib.h>


using namespace cv;
using namespace std;

int main()
{
	Mat image = imread("G:\\123.jpg", CV_LOAD_IMAGE_GRAYSCALE);
	Mat copy = image;
	Mat img(image.rows, image.cols, CV_8UC1, Scalar(0));
	int **a;
	int i, j, l, z;
	int b;
	int c;
	l = 0;
	z = 0;
	a = new int*[(int)image.cols* sizeof(int *)];
	for (i = 0; i < image.cols; i++)
		a[i] = new int[(int)image.rows* sizeof(int)];

	for (i = 0; i < image.rows; i++)
	{
		for (j = 0; j < image.cols; j++)
		{
			a[j][i] = -1;
		}
	}
	for (i = 0; i < copy.rows; i++)
	{
		for (j = 0; j < copy.cols; j++)
		{
			queue<Point> q;
			if (copy.at<uchar>(i, j) == 0 && a[j][i] == -1)
			{
				Point front1;
				Point rear;
				front1.x = j;
				front1.y = i;
				q.push(front1);
				l++;
				a[j][i] = l;
				while (1)
				{
					for (b = front1.y - 1; b <= front1.y + 1; b++)
					{
						for (c = front1.x - 1; c <= front1.x + 1; c++)
						{
							if (copy.at<uchar>(b, c) == 0 && a[c][b] == -1)
							{
								rear.x = c;
								rear.y = b;
								a[c][b] = l;
								q.push(rear);
								z++;
							}
						}
					}
					q.pop();
					
					if ( q.empty() == true)
					{
						break;
					}
					front1 = q.front();
				}


			}
		}
	}
		for (i = 0; i < copy.rows; i++)
		{
			for (j = 0; j < copy.cols; j++)
			{
				if (a[j][i]!=-1)
				{
					img.at<uchar>(i, j) =(uchar) 255/(a[j][i]);
				}


			}
		}
		imshow("Window1", img);
		waitKey(0);
	
}


