#include "stdafx.h"
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <stdio.h>
#include "opencv2/imgproc/imgproc.hpp"
#include <iostream>
#include <string>


using namespace cv;
using namespace std;

void main()
{
	CvCapture* capture = cvCreateCameraCapture(0);
	IplImage* frame;
	char* win = "video stream";
	cvNamedWindow(win, CV_WINDOW_AUTOSIZE);
	while (1)
	{
		frame = cvQueryFrame(capture);
		cvShowImage(win, frame);
		char c = cvWaitKey(33);
		if (c == 27)
			break;
	}
	cvReleaseCapture(&capture);
	cvReleaseImage(&frame);
}
