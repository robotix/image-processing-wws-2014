#include "stdafx.h"
#include "iostream"
#include <conio.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <stdio.h>
using namespace cv;
using namespace std;

uchar diff(Mat, int, int);

int main()
{
	int Threshold = 0;
	VideoCapture v("MOV00025.avi");
	while (1)
	{
		Mat image;
		v >> image;
		uchar d;
		int i, j;
		Mat gimage(image.rows, image.cols, CV_8UC1);
		for (i = 0; i < image.rows; i++)
		{
			for (j = 0; j < image.cols; j++)
			{
				gimage.at<uchar>(i, j) = (uchar)(0.56*image.at<Vec3b>(i, j)[0] + 0.33*image.at<Vec3b>(i, j)[1] + 0.11*image.at<Vec3b>(i, j)[2]);
			}
		}


		namedWindow("window1", WINDOW_AUTOSIZE);
		createTrackbar("Threshold", "window1", &Threshold, 255);
		Mat bimage(image.rows, image.cols, CV_8UC1, Scalar(0));
		for (i = 1; i < (image.rows - 1); i++)
		{
			for (j = 1; j<(image.cols - 1); j++)
			{
				d = diff(gimage, i, j);
				if (d>Threshold)
					bimage.at<uchar>(i, j) = 255;
			}
		}

		imshow("window1", bimage);
		int a = waitKey(1);
		if (a == 27)
			break;

	}
	return 0;
}

uchar diff(Mat gimage, int i, int j)
{
	int k, l;
	uchar d;
	uchar s = gimage.at<uchar>(i, j);
	uchar s1 = gimage.at<uchar>(i, j);

	for (k = (i - 1); k <= (i + 1); k++)
	{
		for (l = (j - 1); l <= (j + 1); l++)
		{
			if (s < gimage.at<uchar>(k, l))
				s = gimage.at<uchar>(k, l);
			if (s1 > gimage.at<uchar>(k, l))
				s1 = gimage.at<uchar>(k, l);
		}
	}
	d = s - s1;
	return d;
}