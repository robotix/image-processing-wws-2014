#include "stdafx.h"
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <stdio.h>
#include "opencv2/imgproc/imgproc.hpp"
#include <iostream>
#include <string>

using namespace std;
using namespace cv;

Mat RedDetectBGR(Mat img, int min_thresh, int max_thresh){

	Mat result(img.rows, img.cols, CV_8UC1);          
	int i, j, r = img.rows, c = img.cols;

	for (i = 0; i<r; i++){                              
		for (j = 0; j<c; j++){                           

			Vec3b colours = img.at<Vec3b>(i, j);     
			if (colours[2] >= min_thresh && colours[1]<max_thresh && colours[0]<max_thresh)
				result.at<uchar>(i, j) = 255;        
			else
				result.at<uchar>(i, j) = 0;          
		}
	}

	return result;
}

int main()
{

	Mat image = imread("tulip.jpg");
	int minthresh = 80, maxthresh = 100;

	string win_name = "Colour-extracted image";
	namedWindow(win_name, CV_WINDOW_NORMAL);
	imshow("Original image", image);
	createTrackbar("Low Threshold", win_name, &minthresh, 255);
	createTrackbar("High Threshold", win_name, &maxthresh, 255);

	while (1){
		Mat result = RedDetectBGR(image, minthresh, maxthresh);
		imshow(win_name, result);
		char ch = waitKey(33);
		if (ch == 27)
			break;
	}

	image.release();
	destroyAllWindows();
	return 0;
}