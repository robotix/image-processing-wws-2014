#include "stdafx.h"
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <stdio.h>
#include "opencv2/imgproc/imgproc.hpp"
#include <iostream>
#include <string>

using namespace std;
using namespace cv;

int main(){
	Mat image;
	Mat gray;
	Mat hsv;
	VideoCapture cap;
	cap.open(0);
	namedWindow("window", CV_WINDOW_AUTOSIZE);
	namedWindow("hsv", CV_WINDOW_AUTOSIZE);

	while (1){
		cap >> image;
		cvtColor(image, gray, CV_BGR2GRAY);
		cvtColor(image, hsv, CV_BGR2HSV);
		imshow("window", image);
		imshow("hsv", hsv);
		waitKey(33);
	}
	return 0;
}