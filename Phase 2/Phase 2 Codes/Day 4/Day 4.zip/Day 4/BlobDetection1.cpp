#include "stdafx.h"
#include<iostream>
#include<queue>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
using namespace std;
using namespace cv;

void main()
{
	int i, j;
	queue <Point> q;
	Mat img = imread("blobs.jpg", CV_LOAD_IMAGE_GRAYSCALE);
	namedWindow("window", WINDOW_NORMAL);
	imshow("window", img);
	waitKey(0);
	Mat A(img.rows, img.cols, CV_8SC1, Scalar(-1));
	int c = 1;
	for (i = 0; i < img.rows; i++)
	for (j = 0; j < img.cols; j++)
	{
		if (img.at<uchar>(i, j) == 255 && A.at<schar>(i, j) == -1)
		{
			Point p;
			p.x = i;
			p.y = j;
			q.push(p);
			A.at<schar>(p.x, p.y) = 0;
			while (!q.empty())
			{
				p = q.front();
				for (int k = -1; k <= 1; k++)
				for (int l = -1; l <= 1; l++)
				if (img.at<uchar>(q.front().x + k, q.front().y + l) == 255 && A.at<schar>(i, j) == -1)
				{
					p.x = q.front().x + k;
					p.y = q.front().y + l;
					q.push(p);
					A.at<schar>(p.x, p.y) = 0;
				}
				p = q.front();
				A.at<schar>(p.x, p.y) = c;
				q.pop();
			}
			c++;
		}
	}
	int n;
	cout << "Enter blob number";
	cin >> n;
	Mat blob(img.rows, img.cols, CV_8UC1, Scalar(0));
	for (i = 0; i < img.rows; i++)
	{
		for (j = 0; j < img.cols; j++)
		{
			if (A.at<schar>(i, j) == n)
				blob.at<uchar>(i, j) = 255;
		}
	}
	namedWindow("Window1", WINDOW_NORMAL);
	imshow("Window1", blob);
	waitKey(0);

}