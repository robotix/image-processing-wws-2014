#include "stdafx.h"
#include<iostream>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
using namespace std;
using namespace cv;

/*Mat noisegaussian(Mat grey)
{
	int i, j, k, l;
	Mat red = grey.clone();
	for (i = 0; i < grey.rows; i++)
	for (j = 0; j < grey.cols; j++)
	{
		double sum = 0;
		for (k = 0; k < 3; k++)
		for (l = 0; l < 3; l++)
		{
			double a;
			if (k == 1 || l == 1)
			{
				if (k == 1 && l == 1)
					a = 0.162;
				else a = 0.098;

			}
			else a = 0.06;
			sum += a*grey.at<uchar>(((i + k) < grey.rows) ? (i + k) : (grey.rows - 1), ((j + l) < grey.cols) ? (j + l) : (grey.cols - 1));
		}
		red.at<uchar>(((i + 1) < red.rows) ? (i + 1) : (red.rows - 1), ((j + 1) < red.cols) ? (j + 1) : (red.cols - 1)) = (int)(sum);
	}
	return red;

void main()
{
	int t = 11, h=149;
	Mat img = imread("ShapesRandomly.jpg");
	Mat image;
	cvtColor(img, image, CV_BGR2HLS_FULL);
	imshow("Original", img);
	waitKey(0);
	namedWindow("Colour Detection", WINDOW_NORMAL);
	createTrackbar("Tolerance", "Colour Detection", &t, 50);
	createTrackbar("Hue", "Colour Detection", &h, 255);
	while (1)
	{
		Mat final(img.rows, img.cols, CV_8UC1, Scalar(0));
		for (int i = 0; i < image.rows; i++)
		{
			for (int j = 0; j < image.cols; j++)
			{
				if (image.at<Vec3b>(i, j)[0]>(h - (t*255/360)) && image.at<Vec3b>(i, j)[0] < (h + (t*255/360)))
					final.at<uchar>(i, j) = 255;
			}
		}
		
		imshow("Colour Detection", final);
		imshow("After Noise Removal", noisegaussian(final));
		int a = waitKey(20);
		
		if (a == 27)
			break;
	}
	

}*/