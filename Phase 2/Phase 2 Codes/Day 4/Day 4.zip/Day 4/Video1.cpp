#include "stdafx.h"
#include<iostream>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
using namespace std;
using namespace cv;
/*int main()
{
	VideoCapture movie("simpsons- dexter.mp4");
	int t = 33,t1=40,t2=120;
	namedWindow("Simpsons Dexter 1", WINDOW_AUTOSIZE);
	namedWindow("Simpsons Dexter 2", WINDOW_AUTOSIZE);
	namedWindow("Simpsons Dexter 3", WINDOW_AUTOSIZE);
	createTrackbar("waitKey", "Simpsons Dexter 1", &t, 200);
	createTrackbar("waitKey", "Simpsons Dexter 2", &t, 200);
	createTrackbar("waitKey", "Simpsons Dexter 3", &t, 200);
	createTrackbar("LowerThreshold", "Simpsons Dexter 3", &t1, 255);
	createTrackbar("UpperThreshold", "Simpsons Dexter 3", &t2, 255);
	while (1)
	{   
		Mat frame;
		movie >> frame;
		
		Mat frame1(frame.rows, frame.cols, CV_8UC1);
		
		for (int i = 0; i < frame.rows; i++)
		{
			for (int j = 0; j < frame.cols; j++)
			{
				frame1.at<uchar>(i, j) = (0.56*frame.at<Vec3b>(i, j)[0] + 0.33*frame.at<Vec3b>(i, j)[1] + 0.11*frame.at<Vec3b>(i, j)[2]);
			}
		}
		Mat frame2(frame.rows, frame.cols, CV_8UC1);
		Canny(frame, frame2, t1, t2);
		imshow("Simpsons Dexter 1", frame);
		imshow("Simpsons Dexter 2", frame1);
		imshow("Simpsons Dexter 3", frame2);
		int a=waitKey(t);
		if (a == 27)
			break;
	} return 0;
}*/