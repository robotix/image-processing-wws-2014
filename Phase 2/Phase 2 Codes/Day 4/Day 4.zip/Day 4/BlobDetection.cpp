#include "stdafx.h"
#include<iostream>
#include<queue>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
using namespace std;
using namespace cv;

//void search( int y,int x, Mat A,int c,Mat img)
//{
//
//	for (int i = (y - 1); i <= (y + 1);i++)
//	for (int j = (x - 1); j <= (x + 1); j++)
//	{
//		
//		if (img.at<uchar>(i, j) == 255 && A.at<schar>(i, j) == -1)
//		{
//		
//			A.at<schar>(i, j) = c;
//			search(i, j,A,c,img);
//		}
//	}  
//	
//}
//
//void main()
//{
//	int i, j;
//	Mat img = imread("blobs.jpg",CV_LOAD_IMAGE_GRAYSCALE);
//	Mat A(img.rows, img.cols, CV_8SC1, Scalar(-1));
//	int c = 0;
//	for ( i = 0; i < img.rows;i++)
//	for ( j = 0; j < img.cols; j++)
//	{
//		if (img.at<uchar>(i, j) == 255 && A.at<schar>(i, j) == -1)
//		{
//			A.at<schar>(i,j)= ++c;
//			search(i, j,A,c,img);
//		}
//	}
//	Mat image(img.rows, img.cols, CV_8UC1, Scalar(0));
//	for (i = 0; i < img.rows;i++)
//	for (j = 0; j < img.cols; j++)
//	{
//		if (A.at<schar>(i, j) = 1)
//			image.at<uchar>(i, j) = 255;
//	}
//	imshow("Window", image);
//}