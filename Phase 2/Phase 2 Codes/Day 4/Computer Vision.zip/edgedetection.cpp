#include"stdafx.h"
#include <iostream>
#include "vector"
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
using namespace std;
using namespace cv;

Mat edgedetection(Mat image,int threshold)
{
	Mat img(image.rows, image.cols,CV_8UC1, Scalar(0));
	int i, j, k, l;
	for (i = 1; i < image.rows-1; i++)
	{
		for (j = 1; j < image.cols - 1; j++)
		{
			int max = 0, min = 255;
			for (k = i - 1; k <= i + 1; k++)
			{
				for (l = j - 1; l<= j + 1; l++)
				{
					max = ((image.at<uchar>(k, l) > max) ? image.at<uchar>(k, l) : max);
					min = ((image.at<uchar>(k, l) < min) ? image.at<uchar>(k, l) : min);
				}
			}
			if ((max - min)>threshold)
				img.at<uchar>(i,j) = 255;
		}
	}
	return img;


}
void main()
{
	Mat image = imread("E:\\10581354_711909362211041_1728452688_n.jpg", CV_LOAD_IMAGE_GRAYSCALE);
	//Mat img(image.rows, image.cols, CV_8UC1, Scalar(0));
	int =10;
	namedWindow("Edge", WINDOW_NORMAL);
	createTrackbar("Threshold", "Edge", &x, 255);
	while (1)
	{
		Mat img = edgedetection(image, x);
		namedWindow("Edge", WINDOW_NORMAL);
		imshow("Edge", img);
		char a = waitKey(33);
		if (a == 27)
			break;
	}
}