#include"stdafx.h"
#include <iostream>
#include "vector"
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
using namespace std;
using namespace cv;
int main()
{
	int a, b,threshold=30;
	Mat image = imread("E:\\10581354_711909362211041_1728452688_n.jpg", CV_LOAD_IMAGE_COLOR);
	Mat img(image.rows, image.cols, CV_8UC1);
	for (b = 0; b < image.cols; b++)
	{
		for (a = 0; a < image.rows; a++)
		{
			img.at<uchar>(a, b) = (uchar)(((image.at<Vec3b>(a, b)[0])*0.56) + ((image.at<Vec3b>(a, b)[1])*0.33) + ((image.at<Vec3b>(a, b)[2])*0.11));
		}
	}
	for (b = 0; b < image.cols; b++)
	{
		for (a = 0; a < image.rows; a++)
		{
			if ((img.at<uchar>(a, b))>threshold)
				img.at<uchar>(a, b) = 255;
			else
			img.at<uchar>(a, b) = 0;
		}
	}
	namedWindow("Bin", WINDOW_NORMAL);
	imshow("Bin", img);
	waitKey(0);
	return 0;

}