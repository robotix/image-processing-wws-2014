#include"stdafx.h"
#include <iostream>
#include "vector"
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
using namespace std;
using namespace cv;
int Main()
{
	int a=30, b=50;
	Mat image = imread("E:\\10581354_711909362211041_1728452688_n.jpg", CV_LOAD_IMAGE_GRAYSCALE);
	Mat img(image.rows, image.cols, CV_8UC1);
	namedWindow("Canny", WINDOW_NORMAL);
	createTrackbar("ThresholdLower", "Canny", &a, 255);
	createTrackbar("ThresholdHigh", "Canny", &b, 255);
	while (1)
	{
		
		Canny(image, img, a, b);
		namedWindow("Canny", WINDOW_NORMAL);
		imshow("Canny", img);
		char d = waitKey(33);
		if (d == 27)
			break;
	}
	return 0;
}

