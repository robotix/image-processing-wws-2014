#include"stdafx.h"
#include <iostream>
#include<math.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

using namespace std;
using namespace cv;
void sortarray(int A[],int n)
{
	int i, j, t;
	for (i = 0; i < n; i++)
	{
		t = A[i];
		for (j = i-1; j>=0;j--)
		{
			if (t>A[j])
			{
				A[j + 1] = A[j];
				A[j] = t;
			}
			else break;
		}
	}
}
void median(Mat greyimage,Mat image)
{  
		for (int i = 1; i < (greyimage.rows - 2); i++)
	{
		for (int j = 1; j < (greyimage.cols - 2); j++)
		{
			int a[9];
			int l = 0;
			for (int k = (i - 1); k <= (i + 1); k++)
			{
				for (int s = (j - 1); s <= (j + 1); s++)
				{
					a[l] = greyimage.at<uchar>(k, s);
					l++;
				}
			}
			sortarray(a, 9);
			image.at<uchar>(i, j) = a[4];
		}
	}
}

void gausian(Mat greyimage,Mat image)
{
	int y;
	for (int i = 1; i < (greyimage.rows - 2); i++)
	{
		for (int j = 1; j < (greyimage.cols - 2); j++)
		{
			y = 0;
			for (int k = (i - 1); k <= (i + 1); k++)
			{
				for (int s = (j - 1); s <= (j + 1); s++)
				{
					if (((k == (i - 1)) || (k == (i + 1))) && ((s == (j - 1)) || (s == (j + 1))))
						y += (.06*(greyimage.at<uchar>(k, s)));
					else if ((k == i) && (s == j))
						y += (.162*(greyimage.at<uchar>(k, s)));
					else
						y += (.098*(greyimage.at<uchar>(k, s)));
				}
			}
			image.at < uchar >(i, j) = y;
		}
	}
}
void greyscale(Mat colorimage, Mat greyimage)
{
	for (int i = 0; i < colorimage.rows; i++)
	{
		for (int j = 0; j < colorimage.cols; j++)
		{
			greyimage.at<uchar>(i, j) = ((colorimage.at<Vec3b>(i, j)[0])*.56) + ((colorimage.at<Vec3b>(i, j)[1])*.33) + ((colorimage.at<Vec3b>(i, j)[2])*.11);
		}
	}
}
void kernel(Mat greyimage, Mat image)
{
	int x;
	for (int i = 1; i < (greyimage.rows - 2); i++)
	{
		for (int j = 1; j < (greyimage.cols - 2); j++)
		{
			x = 0;
			for (int k = (i - 1); k <= (i + 1); k++)
			{
				for (int s = (j - 1); s <= (j + 1); s++)
				{
					x += greyimage.at<uchar>(k, s);
				}
			}
			image.at < uchar >(i, j) = x / 9;
		}
	}
}
int main()
{
	int x = 50;
	int y = 150;
	Mat image = imread("c:\\tree.jpg", CV_LOAD_IMAGE_COLOR);
	Mat image2(image.rows, image.cols, CV_8UC1);
	Mat image3(image.rows, image.cols, CV_8UC1);
	Mat image4(image.rows, image.cols, CV_8UC1);
	Mat image5(image.rows, image.cols, CV_8UC1);
	Mat image6(image.rows, image.cols, CV_8UC1);
	greyscale(image, image2);
	kernel(image2, image3);
	gausian(image2, image4);
	median(image2, image5);
	Canny(image2, image6, 50, 150);
	namedWindow("Greyimage", WINDOW_NORMAL);
	imshow("Greyimage", image2);
	waitKey(0);
	namedWindow("Mean", WINDOW_NORMAL);
	imshow("Mean", image3);
	waitKey(0);
	namedWindow("GAUSIAN", WINDOW_NORMAL);
	imshow("Gausian", image4);
	waitKey(0);
	namedWindow("Median", WINDOW_NORMAL);
	imshow("Median", image5);
	waitKey(0);
	namedWindow("CANNY", WINDOW_NORMAL);
	createTrackbar("minthreshold", "CANNY", &x, 255);
	createTrackbar("maxthreshold", "CANNY", &y, 255);
	
	while (1)
	{
		Canny(image2, image6, x, y);
		imshow("CANNY", image6);
		char a=waitKey(33);
		if (a == 27)
			break;
	}
}