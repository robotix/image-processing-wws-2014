#include"stdafx.h"
#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

using namespace std;
using namespace cv;
/*void greyscale(Mat colorimage, Mat greyimage)
{
	for (int i = 0; i < colorimage.rows; i++)
	{
		for (int j = 0; j < colorimage.cols; j++)
		{
			greyimage.at<uchar>(i, j) = ((colorimage.at<Vec3b>(i, j)[0])*.56) + ((colorimage.at<Vec3b>(i, j)[1])*.33) + ((colorimage.at<Vec3b>(i, j)[2])*.11);
		}
	}
}

Mat kernel(Mat greyimage,int t)
{
	Mat image3(greyimage.rows, greyimage.cols, CV_8UC1, Scalar(0));
	int max, min;
	for (int i = 1; i < (greyimage.rows - 2); i++)
	{
		for (int j = 1; j < (greyimage.cols - 2); j++)
		{
			 max=min= greyimage.at<uchar>(i, j);
			 
			for (int k = (i - 1); k <= (i + 1); k++)
			{
				for (int s = (j - 1); s <= (j + 1); s++)
				{
					if ((greyimage.at<uchar>(k, s)) >= max)
						max = (greyimage.at<uchar>(k, s));
					if((greyimage.at<uchar>(k, s)) < min)
						min = (greyimage.at<uchar>(k, s));
				}

			}
			if ((max - min)>t)
				image3.at <uchar>(i,j)= 255;
		}
}
	return image3;
}
int main()
{
	int x = 125;
	Mat image = imread("c:\\tree.jpg", CV_LOAD_IMAGE_COLOR);
	Mat image2(image.rows, image.cols, CV_8UC1);
	
	greyscale(image, image2);
	namedWindow("EDGES", WINDOW_NORMAL);

}*/