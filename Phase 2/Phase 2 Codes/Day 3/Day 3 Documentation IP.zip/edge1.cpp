#include"stdafx.h"
#include <iostream>
#include<math.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

using namespace std;
using namespace cv;
/*void greyscale(Mat colorimage, Mat greyimage)
{
for (int i = 0; i < colorimage.rows; i++)
{
for (int j = 0; j < colorimage.cols; j++)
{
greyimage.at<uchar>(i, j) = ((colorimage.at<Vec3b>(i, j)[0])*.56) + ((colorimage.at<Vec3b>(i, j)[1])*.33) + ((colorimage.at<Vec3b>(i, j)[2])*.11);
}
}
}
void kernel1(Mat greyimage, Mat image)
{
	int x, y;

	for (int i = 1; i < (greyimage.rows - 2); i++)
	{
		for (int j = 1; j < (greyimage.cols - 2); j++)
		{
			x = y = 0;
			for (int k = (i - 1); k <= (i + 1); k++)
			{
				for (int s = (j - 1); s <= (j + 1); s++)
				{
					if (k<i)
					y+=((-1)*greyimage.at<uchar>(k, s));
					if (k>i)
					y+=greyimage.at<uchar>(k, s);
					if (s<j)
						x += ((-1)*greyimage.at<uchar>(k, s));
					if (s>j)
						x += greyimage.at<uchar>(k, s);
				}
			}
			image.at<uchar>(i, j) = sqrt((x*x) + (y*y));
		}
	}
}

void kernel(Mat greyimage,Mat image)
{
	int x, y;
	
for (int i = 1; i < (greyimage.rows - 2); i++)
{
for (int j = 1; j < (greyimage.cols - 2); j++)
{
	x=y=0;
for (int k = (i - 1); k <= (i + 1); k++)
{
for (int s = (j - 1); s <= (j + 1); s++)
{
	//if (k<i)
		//y+=((-1)*greyimage.at<uchar>(k, s));
	//if (k>i)
		//y+=greyimage.at<uchar>(k, s);
	if (s<j)
		x+=((-1)*greyimage.at<uchar>(k, s));
	if (s>j)
		x+=greyimage.at<uchar>(k, s);
}
}
image.at<uchar>(i, j) = sqrt((x*x) + (y*y));
}
}
}
int main()
{
Mat image = imread("c:\\tree.jpg", CV_LOAD_IMAGE_COLOR);
Mat image2(image.rows, image.cols, CV_8UC1);
Mat image3(image.rows, image.cols, CV_8UC1,Scalar(0));
Mat image4(image.rows, image.cols, CV_8UC1, Scalar(0));
greyscale(image, image2);
kernel(image2, image3);
kernel1(image2, image4);
namedWindow("EDGES", WINDOW_NORMAL);
imshow("EDGES", image3);
waitKey(0);
namedWindow("EDGES1", WINDOW_NORMAL);
imshow("EDGES1", image4);
waitKey(0);
}*/