#include"stdafx.h"
#include <iostream>
#include<math.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

using namespace std;
using namespace cv;
/*void greyscale(Mat colorimage, Mat greyimage)
{
for (int i = 0; i < colorimage.rows; i++)
{
for (int j = 0; j < colorimage.cols; j++)
{
greyimage.at<uchar>(i, j) = ((colorimage.at<Vec3b>(i, j)[0])*.56) + ((colorimage.at<Vec3b>(i, j)[1])*.33) + ((colorimage.at<Vec3b>(i, j)[2])*.11);
}
}
}
void kernel(Mat greyimage, Mat image)
{
	int x, y;

	for (int i = 1; i < (greyimage.rows - 2); i++)
	{
		for (int j = 1; j < (greyimage.cols - 2); j++)
		{
			x = 0;
			for (int k = (i - 1); k <= (i + 1); k++)
			{
				for (int s = (j - 1); s <= (j + 1); s++)
				{
					x += greyimage.at<uchar>(k, s);
				}
			}
			image.at < uchar >(i, j) = x / 9;
		}
	}
}
int main()
{
Mat image = imread("c:\\tree.jpg", CV_LOAD_IMAGE_COLOR);
Mat image2(image.rows, image.cols, CV_8UC1);
Mat image3(image.rows, image.cols, CV_8UC1,Scalar(0));
greyscale(image, image2);
kernel(image2, image3);
namedWindow("Greyimage", WINDOW_NORMAL);
imshow("Greyimage", image2);
waitKey(0);
namedWindow("EDGES", WINDOW_NORMAL);
imshow("EDGES", image3);
waitKey(0);
}*/