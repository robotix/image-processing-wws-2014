// day3_chinmoy.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "stdio.h"
#include "opencv2\core\core.hpp"
#include "opencv2\highgui\highgui.hpp"
using namespace std;
using namespace cv;

int isedge(Mat image,int i,int j,int thresh)
{
	int a, b,max,min;
	max = image.at<uchar>(i - 1, j - 1);
	min = image.at<uchar>(i - 1, j - 1);
	for (a = i - 1; a < i + 2; a++)
	{
		for (b = j - 1; b < j + 2; b++)
		{
			if (image.at<uchar>(a, b)>max)
				max = image.at<uchar>(a, b);
			if (image.at<uchar>(a, b) < min)
				min = image.at<uchar>(a, b);
		}
	}
	if (max - min < thresh)
		return 0;
	else
		return 1;
}
int main(int argc, _TCHAR* argv[])
{
	Mat image = imread("C:\\ronaldo.jpg", 0);
	int rows, cols, thresh=100 , i, j, out;
	rows = image.rows;
	cols = image.cols;
	namedWindow("my window", WINDOW_AUTOSIZE);
	createTrackbar("threshhold", "my window", &thresh, 255);
	while (1)
	{
		Mat image1(image.size(), CV_8UC1, Scalar(0)); 
		for (i = 1; i < rows - 1; i++)
		{
			for (j = 1; j < cols - 1; j++)
			{
				out = isedge(image, i, j, thresh);
				if (out == 1)
					image1.at<uchar>(i, j) = 255;
			}
		}
		imshow("my window", image1);
		char a = waitKey(33);
		if (a == 27)
			break;
	}

	return 0;
}


	
	
	
	

