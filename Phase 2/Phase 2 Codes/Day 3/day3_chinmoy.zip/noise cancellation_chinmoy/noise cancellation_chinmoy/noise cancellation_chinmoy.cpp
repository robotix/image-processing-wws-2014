// noise cancellation_chinmoy.cpp : Defines the entry point for the console application.

#include "stdafx.h"
#include <stdio.h>
#include <iostream>
#include "opencv2\core\core.hpp"
#include "opencv2\highgui\highgui.hpp"
#include "opencv2\imgproc\imgproc.hpp"
using namespace std;
using namespace cv;

int main(int argc, _TCHAR* argv[])
{

	/*noise cancellation noise cancellation noise cancellation noise cancellation noise cancellation noise cancellation



	int isedge(Mat image, int i, int j, int thresh)
	{
	int a, b, max, min;
	max = image.at<uchar>(i - 1, j - 1);
	min = image.at<uchar>(i - 1, j - 1);
	for (a = i - 1; a < i + 2; a++)
	{
	for (b = j - 1; b < j + 2; b++)
	{
	if (image.at<uchar>(a, b)>max)
	max = image.at<uchar>(a, b);
	if (image.at<uchar>(a, b) < min)
	min = image.at<uchar>(a, b);
	}
	}
	if (max - min < thresh)
	return 0;
	else
	return 1;
	}


	int main(int argc, _TCHAR* argv[])
	{
	Mat image;
	image = imread("C:\\circles.jpg", 0);
	int out,rows,cols,thresh,black=0,white=0;
	int i, j,k,l;
	cout << "enter the threshhold value";
	cin >> thresh;
	rows = image.rows;
	cols = image.cols;
	Mat image1(image.size(), 0);
	for (i = 1; i < rows - 1; i++)
	{
	for (j = 1; j < cols - 1; j++)
	{
	out = isedge(image, i, j, thresh);
	if (out == 1)
	image1.at<uchar>(i, j) = 255;
	else
	image1.at<uchar>(i, j) = 0;
	}
	}
	namedWindow("my window", WINDOW_AUTOSIZE);
	imshow("my window", image1);
	waitKey(0);

	Mat image2;
	image1.copyTo(image2);
	for (i = 1; i < rows - 1; i++)
	{
	for (j = 1; j < cols - 1; j++)
	{
	black = 0;
	white = 0;
	for (k = i - 1; k < i + 2; k++)
	{
	for (l = j - 1; l < j + 2; l++)
	{
	if (image1.at<uchar>(k, l) == 0)
	black++;
	else
	white++;
	}
	}
	if (black>white)
	image2.at<uchar>(i, j) = 0;
	else
	image2.at<uchar>(i, j) = 255;
	}
	}
	namedWindow("my window 1", WINDOW_AUTOSIZE);
	imshow("my window 1", image2);
	waitKey(0);

	Mat image3;
	image2.copyTo(image3);
	for (i = 1; i < rows - 1; i++)
	{
	for (j = 1; j < cols - 1; j++)
	{

	black = 0;
	white = 0;
	for (k = i - 1; k < i + 2; k++)
	{
	for (l = j - 1; l < j + 2; l++)
	{
	if (image2.at<uchar>(k, l) == 0)
	black++;
	else
	white++;
	}
	}
	if (black == 0 || white == 0)
	continue;
	else
	{
	if (black > white)
	image3.at<uchar>(i, j) = 255;
	else
	image3.at<uchar>(i, j) = 0;
	}
	}
	}
	namedWindow("my window", WINDOW_AUTOSIZE);
	imshow("my window 2", image3);
	waitKey(0);



	*/


	/*mean mean mean mean

	Mat image;
	image = imread("C://circles.jpg", 0);
	Mat image1;
	image.copyTo(image1);
	int rows, cols, i, j, k, l, sum=0,mean;
	rows = image.rows;
	cols = image.cols;
	for (i = 1; i < rows - 1; i++)
	{
	for (j = 1; j < cols - 1; j++)
	{
	sum = 0;
	for (k = i - 1; k < i + 2; k++)
	{
	for (l = j - 1; l < j + 2; l++)
	{
	sum = sum + image.at<uchar>(k, l);
	}
	}
	mean = sum / 9;
	image1.at<uchar>(i, j) = mean;
	}
	}
	namedWindow("my window", WINDOW_AUTOSIZE);
	imshow("my window", image);
	waitKey(0);
	namedWindow("my window 1", WINDOW_AUTOSIZE);
	imshow("my window 1",image1);
	waitKey(0);
	*/



	//median median median median median median 

	
/*
	Mat image;
	image = imread("C://circles.jpg", 0);
	Mat image2;
	image.copyTo(image2);
	int rows, cols, i, j, k, l, arr[9], m, temp;
	rows = image.rows;
	cols = image.cols;
	for (i = 1; i < rows - 1; i++)
	{
		for (j = 1; j < cols - 1; j++)
		{
			m = 0;
			for (k = i - 1; k < i + 2; k++)
			{
				for (l = j - 1; l < j + 2; l++)
				{
					arr[m++] = image.at<uchar>(k, l);
				}
			}
			int min;
			if (i == 1 && j < 5)
			{

				for (int p = 0; p < 9; ++p)
					cout << arr[p] << " ";
				cout << "\n";
			}
			for (int i = 0; i < 8; i++)
			{

				min =arr[i];
				for (int j = i; j < 9; j++)
				{
					if (arr[j] < min)
					{
						min = arr[j];
						k = j;
					}
				}
				temp = arr[k];
				arr[k] = arr[i];
				arr[i] = temp;
			}
			image2.at<uchar>(i, j) = arr[4];
			if (i == 1 && j < 5)
			{

				for (int p = 0; p < 9; ++p)
					cout << arr[p] << " ";
				cout << "\n";
			}
			}

	}
		
	
	namedWindow("my window", WINDOW_AUTOSIZE);
	imshow("my window", image);
	waitKey(0);
	namedWindow("my window 2", WINDOW_AUTOSIZE);
	imshow("my window 2", image2);
	waitKey(0);
	
*/


/*gaussian gaussian gaussian gaussian gaussian gaussian gaussian gaussian 


Mat image;
image = imread("C://ronaldo.jpg", 0);
Mat image3;
image.copyTo(image3);
int rows, cols, i, j, k, l, arr[9],m,val;
rows = image.rows;
cols = image.cols;
for (i = 1; i < rows - 1; i++)
{
	for (j = 1; j < cols - 1; j++)
	{
		m = 0;
		for (k = i - 1; k < i + 2; k++)
		{
			for (l = j - 1; l < j + 2; l++)
			{
				arr[m++] = image.at<uchar>(i, j);
			}
		}
		val = (arr[0] + arr[2] + arr[6] + arr[8])*0.06 + (arr[1] + arr[3] + arr[5] + arr[7])*0.098 + (arr[4] * 0.162);
		image3.at<uchar>(i, j) = val;
	}
}
namedWindow("my window", WINDOW_AUTOSIZE);
imshow("my window", image);
waitKey(0);
namedWindow("my window 3", WINDOW_AUTOSIZE);
imshow("my window 3", image3);
waitKey(0);


*/



//canny canny canny canny canny canny canny canny canny canny canny 


/*




Mat image;
image = imread("C:\\Users\\CHINMOY SAM\\Pictures\\Canny_Detector_Tutorial_Original_Image.jpg", 0);
Mat image4(image.size(), 0);
int m=0,n=0;
namedWindow("my window 2",WINDOW_AUTOSIZE);
createTrackbar("upper limit", "my window 2", &m, 255);
createTrackbar("lower limit", "my window 2", &n, 255);
while (1)
{
		Canny(image, image4, n, m, 3);
		imshow("my window 2", image4);
		char a=waitKey(33);
		if (a == 27)
			break;
}



*/
	return 0;
}

