// ConsoleApplication2.cpp : Defines the entry point for the console application.
//


#include "stdafx.h"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <iostream>
#include <stdio.h>

using namespace cv;
using namespace std;
/*
Mat edgedetect(Mat image)
{
	int rows, cols, i, j, k, l, delx = 0, dely = 0;
	double del;
	rows = image.rows;
	cols = image.cols;
	Mat image1(image.size(), CV_8UC1);
	for (i = 1; i < rows - 1; i++)
	{
		for (j = 1; j < cols - 1; j++)
		{
			delx = 0; dely = 0;
			for (k = j - 1; k < j + 2; k++)
			{
				dely = dely + image.at<uchar>(i + 1, k) - image.at<uchar>(i - 1, k);
			}
			for (l = i - 1; l < i + 2; l++)
			{
				delx = delx + image.at<uchar>(l, j + 1) - image.at<uchar>(l, j - 1);
			}
			del = sqrt((delx*delx) + (dely*dely));
			image1.at<uchar>(i, j) = del;
		}
	}
	return image1;
}

int main(int argc, char** argv)
{
	Mat image = imread("C:\\Users\\CHINMOY SAM\\Pictures\\circles.jpg", 0);
	Mat image1(image.size(), 0), image2(image.size(), 0), image3(image.size(), 0), image4(image.size(), 0), image5(image.size(), 0), image6(image.size(), 0), image7(image.size(), 0), image8(image.size(), 0), image9(image.size(), 0), image10(image.size(), 0), image11(image.size(), 0);
	image1 = edgedetect (image);
	image2 = edgedetect (image1);
	image3 = edgedetect(image2);
    image4 = edgedetect(image3);
	image5 = edgedetect(image4);
	image6 = edgedetect(image5);
	image7 = edgedetect(image6);
	image8 = edgedetect(image7);
	image9 = edgedetect(image8);
	image10 = edgedetect(image9);
	image11 = edgedetect(image10);
	namedWindow("my window", WINDOW_AUTOSIZE);
	namedWindow("my window1", WINDOW_AUTOSIZE);
	namedWindow("my window2", WINDOW_AUTOSIZE);
	namedWindow("my window3", WINDOW_AUTOSIZE);
	namedWindow("my window4", WINDOW_AUTOSIZE);
	namedWindow("my window5", WINDOW_AUTOSIZE);
	namedWindow("my window6", WINDOW_AUTOSIZE);
	namedWindow("my window7", WINDOW_AUTOSIZE);
	namedWindow("my window8", WINDOW_AUTOSIZE);
	namedWindow("my window9", WINDOW_AUTOSIZE);
	namedWindow("my window10", WINDOW_AUTOSIZE);
	namedWindow("my window11", WINDOW_AUTOSIZE);
	imshow("my window", image);
	waitKey(0);
	imshow("my window1", image1);
	waitKey(0);
	imshow("my window2", image2);
	waitKey(0);
	imshow("my window3", image3);
	waitKey(0);
	imshow("my window4", image4);
	waitKey(0);
	imshow("my window5", image5);
	waitKey(0);
	imshow("my window6", image6);
	waitKey(0);
	imshow("my window7", image7);
	waitKey(0);
	imshow("my window8", image8);
	waitKey(0);
	imshow("my window9", image9);
	waitKey(0);
	imshow("my window10", image10);
	waitKey(0);
	imshow("my window11", image11);
	waitKey(0);
	return 0;
}
*/
/*
Mat edgedetect(Mat image)
{
	int rows, cols, i, j, k, l, delx = 0, dely = 0;
	double del;
	rows = image.rows;
	cols = image.cols;
	Mat image1(image.size(), CV_8UC1);
	for (i = 1; i < rows - 1; i++)
	{
		for (j = 1; j < cols - 1; j++)
		{
			delx = 0; dely = 0;
			for (k = j - 1; k < j + 2; k++)
			{
				dely = dely + image.at<uchar>(i + 1, k) - image.at<uchar>(i - 1, k);
			}
			for (l = i - 1; l < i + 2; l++)
			{
				delx = delx + image.at<uchar>(l, j + 1) - image.at<uchar>(l, j - 1);
			}
			del = sqrt((delx*delx) + (dely*dely));
			image1.at<uchar>(i, j) = del;
		}
	}
	return image1;
}
int main(int argc, char** argv)
{
	Mat image = imread("C:\\Users\\CHINMOY SAM\\Pictures\\circles.jpg", 0);
	int i = 0, d = 1;
	namedWindow("my window", WINDOW_AUTOSIZE);
	createTrackbar("no of times", "my window", &d, 100);
	while (1)
	{
		for (i = 0; i < d; i++)
		{
			image = edgedetect(image);
		}
		imshow("my window", image);
		char a = waitKey(0);
		if (a == 27)
			break;
	}

	return 0;
}
*/

