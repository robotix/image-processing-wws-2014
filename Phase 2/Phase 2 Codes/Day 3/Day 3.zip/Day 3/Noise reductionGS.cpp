#include "stdafx.h"
#include<iostream>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
using namespace std;
using namespace cv;
//Mat noisemean(Mat grey)
//{
//	int i, j, k, l;
//	Mat red(grey.rows, grey.cols, CV_8UC1);
//	for (i = 0; i < grey.rows; i++)
//	for (j = 0; j < grey.cols; j++)
//		red.at<uchar>(i, j) = grey.at<uchar>(i, j);
//	for (i = 0; i < grey.rows; i++)
//	for (j = 0; j < grey.cols; j++)
//	{
//		int sum = 0;
//		for (k = 0; k < 3; k++)
//		for (l = 0; l < 3; l++)
//			sum += grey.at<uchar>(((i + k) < grey.rows) ? (i + k) : (grey.rows - 1), ((j + l) < grey.cols) ? (j + l) : (grey.cols - 1));
//		red.at<uchar>(((i + 1) < red.rows) ? (i + 1) : (red.rows - 1), ((j + 1) < red.cols) ? (j + 1) : (red.cols - 1)) = (int)(sum /9);
//	}
//	return red;
//}
//Mat noisemedian(Mat grey)
//{
//	int i, j, k, l;
//	//Mat red=grey.clone();
//	Mat red(grey.rows, grey.cols, CV_8UC1);
//	for (i = 0; i < grey.rows; i++)
//	for (j = 0; j < grey.cols; j++)
//		red.at<uchar>(i, j) = grey.at<uchar>(i, j);
//	
//	for (i = 0; i < grey.rows; i++)
//	for (j = 0; j < grey.cols; j++)
//	{
//		int A[9] = { 0, };
//		for (k = 0; k < 3; k++)
//		for (l = 0; l < 3; l++)
//			A[3*k + l] = grey.at<uchar>(((i + k) < grey.rows) ? (i + k) : (grey.rows - 1), ((j + l) < grey.cols) ? (j + l) : (grey.cols - 1));
//		for (int p = 0; p < 9; p++)
//		{
//			int min, index;
//			for (int n = p; n < 9; n++)
//			{
//				
//				if (n == p)
//					min = A[n];
//				else if (A[n] < min)
//				{
//				  index = n;
//					min = A[n];
//				}
//			}
//			int c = A[p];
//			A[p] = A[index];
//			A[index] = c;
//		}
//		red.at<uchar>(((i + 1) < red.rows) ? (i + 1) : (red.rows - 1), ((j + 1) < red.cols) ? (j + 1) : (red.cols - 1)) = A[4];
//	}
//	return red;
//}
//Mat noisegaussian(Mat grey)
//{
//	int i, j, k, l;
//	Mat red = grey.clone();
//	for (i = 0; i < grey.rows; i++)
//	for (j = 0; j < grey.cols; j++)
//	{
//		double sum = 0;
//		for (k = 0; k < 3; k++)
//		for (l = 0; l < 3; l++)
//		{
//			double a;
//			if (k == 1 || l == 1)
//			{
//				if (k == 1 && l == 1)
//					a = 0.162;
//				else a = 0.098;
//
//			}
//			else a = 0.06;
//			sum += a*grey.at<uchar>(((i + k) < grey.rows) ? (i + k) : (grey.rows - 1), ((j + l) < grey.cols) ? (j + l) : (grey.cols - 1));
//		}
//		red.at<uchar>(((i + 1) < red.rows) ? (i + 1) : (red.rows - 1), ((j + 1) < red.cols) ? (j + 1) : (red.cols - 1)) = (int)(sum);
//	}
//	return red;
//}
//void main()
//{
//	Mat image;
//	image = imread("minionadvice.jpg");
//	Mat img(image.rows, image.cols, CV_8UC1);
//	for (int i = 0; i < image.rows; i++)
//	{
//		for (int j = 0; j < image.cols; j++)
//		{
//			img.at<uchar>(i, j) = (0.56*image.at<Vec3b>(i, j)[0] + 0.33*image.at<Vec3b>(i, j)[1] + 0.11*image.at<Vec3b>(i, j)[2]);
//		}
//	}
//	imshow("Original", img);
//	waitKey(0);
//	imshow("Median", noisemedian(img));
//	waitKey(0);
//	imshow("Mean", noisemean(img));
//	waitKey(0);
//	imshow("Gaussian", noisegaussian(img));
//	waitKey(0);
//
//}
