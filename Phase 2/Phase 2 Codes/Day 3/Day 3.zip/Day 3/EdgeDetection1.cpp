#include "stdafx.h"
#include<iostream>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
using namespace std;
using namespace cv;
//Mat edgedetect(Mat grey, int t)
//{
//	Mat grey1(grey.rows, grey.cols, CV_8UC1, Scalar(0));
//	for (int i = 0; i < grey.rows; i++)
//	{
//		for (int j = 0; j < grey.cols; j++)
//		{
//			int max = 0, min = 255, k, l;
//			for (k = 0; k < 3; k++)
//			{
//				for (l = 0; l < 3; l++)
//				{
//					max = (grey.at<uchar>(((i + k)<grey.rows) ? (i + k) : (grey.rows - 1), ((j + l)<grey.cols) ? (j + l) : (grey.cols - 1))>max) ? grey.at<uchar>(((i + k)<grey.rows) ? (i + k) : (grey.rows - 1), ((j + l)<grey.cols) ? (j + l) : (grey.cols - 1)) : max;
//					min = (grey.at<uchar>(((i + k)<grey.rows) ? (i + k) : (grey.rows - 1), ((j + l)<grey.cols) ? (j + l) : (grey.cols - 1))<min) ? grey.at<uchar>(((i + k)<grey.rows) ? (i + k) : (grey.rows - 1), ((j + l)<grey.cols) ? (j + l) : (grey.cols - 1)) : min;
//
//				}
//			}
//			if ((max - min)>t)
//				grey1.at<uchar>(((i + 1) < grey1.rows) ? (i + 1) : (grey1.rows - 1), ((j + 1) < grey1.cols) ? (j + 1) : (grey1.cols - 1)) = 255;
//
//		}
//	}  return grey1;
//}
//
//Mat noisered(Mat edge)
//{
//	for (int i = 0; i < edge.rows; i++)
//	{
//		for (int j = 0; j < edge.cols; j++)
//		{
//			int sumw = 0, sumb = 0;
//			for (int k = 0; k < 3; k++)
//			{
//				for (int l = 0; l < 3; l++)
//				{
//					if (edge.at<uchar>(((i + k) < edge.rows) ? (i + k) : (edge.rows - 1), ((j + l) < edge.cols) ? (j + l) : (edge.cols - 1)) == 255)
//						sumw += 1;
//					else sumb += 1;
//				}
//			}
//			if (sumb>sumw)
//				edge.at<uchar>(((i + 1) < edge.rows) ? (i + 1) : (edge.rows - 1), ((j + 1) < edge.cols) ? (j + 1) : (edge.cols - 1)) = 0;
//			else
//				edge.at<uchar>(((i + 1) < edge.rows) ? (i + 1) : (edge.rows - 1), ((j + 1) < edge.cols) ? (j + 1) : (edge.cols - 1)) = 255;
//		}
//	}
//	for (int i = 0; i < edge.rows; i++)
//	{
//		for (int j = 0; j < edge.cols; j++)
//		{
//			int sumw = 0, sumb = 0;
//			for (int k = 0; k < 3; k++)
//			{
//				for (int l = 0; l < 3; l++)
//				{
//					if (edge.at<uchar>(((i + k) < edge.rows) ? (i + k) : (edge.rows - 1), ((j + l) < edge.cols) ? (j + l) : (edge.cols - 1)) == 255)
//						sumw += 1;
//					else sumb += 1;
//				}
//			}
//			if ((sumb>sumw) && sumw!=0)
//				edge.at<uchar>(((i + 1) < edge.rows) ? (i + 1) : (edge.rows - 1), ((j + 1) < edge.cols) ? (j + 1) : (edge.cols - 1)) = 255;
//			else if((sumw>sumb) && sumb!=0)
//				edge.at<uchar>(((i + 1) < edge.rows) ? (i + 1) : (edge.rows - 1), ((j + 1) < edge.cols) ? (j + 1) : (edge.cols - 1)) = 0;
//		}
//	}
//	return edge;
//}
//void main()
//{
//	Mat image;
//	image = imread("minionadvice.jpg");
//	Mat img(image.rows, image.cols, CV_8UC1);
//	for (int i = 0; i < image.rows; i++)
//	{
//		for (int j = 0; j < image.cols; j++)
//		{
//			img.at<uchar>(i, j) = (0.56*image.at<Vec3b>(i, j)[0] + 0.33*image.at<Vec3b>(i, j)[1] + 0.11*image.at<Vec3b>(i, j)[2]);
//		}
//	}
//	int t = 35;
//	namedWindow("Peekaboo", WINDOW_AUTOSIZE);
//	createTrackbar("Threshold", "Peekaboo", &t, 255);
//	while (1)
//	{
//		Mat edge = edgedetect(img, t);
//		edge = noisered(edge);
//		imshow("Peekaboo", edge);
//		int a = waitKey(33);
//		if (a == 27)
//			break;
//	}
//
//}