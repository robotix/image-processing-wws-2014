#include "stdafx.h"
#include<iostream>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
using namespace std;
using namespace cv;
int main()
{
	Mat image;
	int t1=30, t2=100;
	image = imread("minionadvice.jpg");
	if (!image.data)
		return -1;
	Mat img(image.rows, image.cols, CV_8UC1);
	Mat img1/*(image.rows, image.cols, CV_8UC1,Scalar(255))*/;
	namedWindow("Peekaboo", WINDOW_AUTOSIZE);
	createTrackbar("LowerThreshold", "Peekaboo", &t1, 255);
	createTrackbar("UpperThreshold", "Peekaboo", &t2, 255);
	while (1)
	{
		Mat img = imread("minionadvice.jpg", CV_LOAD_IMAGE_GRAYSCALE);
		Canny(img, img1, t1, t2);
		imshow("Peekaboo", img1);
		int a = waitKey(33);
		if (a == 27)
			break;

	}
	return 0;
}